<?php

class ReminderTemplateEntry extends Eloquent {
    protected $table = 'reminder_template';
    public $timestamps = false;
}