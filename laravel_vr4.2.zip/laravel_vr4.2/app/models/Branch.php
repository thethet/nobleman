<?php

class Branch extends Eloquent {
	protected $fillable = ['name','information','code'];
}