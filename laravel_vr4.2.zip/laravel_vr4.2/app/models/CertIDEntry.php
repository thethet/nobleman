<?php

class CertIDEntry extends Eloquent {
	protected $table = 'certid';
	public $timestamps = false;
}