<?php

class SettingEntry extends Eloquent {
	protected $table = 'settings'; 
	public $timestamps = false;
}