<?php

class Courses1Entry extends Eloquent {
    protected $table = 'courses_old';
    public $timestamps = false;
}