<?php

class TrainersEntry extends Eloquent {
	protected $table = 'trainers'; 
	public $timestamps = false;
}