<?php

class HolidaysEntry extends Eloquent {
    protected $table = 'holidays';
    public $timestamps = false;
}