<?php

class StudentCourseEntry extends Eloquent {
    protected $table = 'student_course';
    public $timestamps = false;
}