<?php

class SessionsEntry extends Eloquent {
    protected $table = 'lesson_sessions';
    public $timestamps = false;
}