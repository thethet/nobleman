<?php

class TrainerScheduleSessionEntry extends Eloquent {
	protected $table = 'trainer_schedule_session'; 
	public $timestamps = false;
}