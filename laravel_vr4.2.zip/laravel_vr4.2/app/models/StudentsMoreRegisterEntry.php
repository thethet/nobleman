<?php

class StudentsMoreRegisterEntry extends Eloquent {
    protected $table = 'student_course_register';
    public $timestamps = false;
}