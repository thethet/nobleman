<?php

class AppointmentEntry extends Eloquent {
	protected $table = 'appointment'; 
	public $timestamps = false;
}