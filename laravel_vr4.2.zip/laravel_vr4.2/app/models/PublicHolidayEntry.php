<?php

class PublicHolidayEntry extends Eloquent {
	protected $table = 'public_holidays'; 
	public $timestamps = false;
}