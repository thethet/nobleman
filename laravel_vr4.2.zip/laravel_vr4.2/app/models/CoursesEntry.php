<?php

class CoursesEntry extends Eloquent {
    protected $table = 'courses';
    public $timestamps = false;
}