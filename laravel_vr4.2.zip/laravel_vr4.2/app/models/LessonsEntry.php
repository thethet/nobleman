<?php

class LessonsEntry extends Eloquent {
    protected $table = 'lessons';
    public $timestamps = false;
}