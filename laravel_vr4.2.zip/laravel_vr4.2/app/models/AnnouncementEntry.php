<?php

class AnnouncementEntry extends Eloquent {
	protected $table = 'announcement'; 
	public $timestamps = false;
}