<?php

class CountryEntry extends Eloquent {
	protected $table = 'countries';
	public $timestamps = false;
}