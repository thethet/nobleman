<?php

class TrainerScheduleEntry extends Eloquent {
	protected $table = 'trainer_schedule'; 
	public $timestamps = false;
}