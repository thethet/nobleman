@extends ('layouts.main')

@section('content')
adsa

@stop