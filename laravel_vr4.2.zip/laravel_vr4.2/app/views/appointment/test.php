<?php
	$html = "Hello!";
	$data = array('html'=>$html);
    echo json_encode($data);
?>
